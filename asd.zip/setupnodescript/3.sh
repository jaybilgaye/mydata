
#!/bin/bash
echo Installing cloudera manager agent for given CMSERVER 
echo Please enter CMVER value to install agent  on nodes.
read cmver

#CMVER=5.10.2
CMVER=$cmver
echo This will take some time relax.
cd /root/hadoop-deployment-bash/
./install_clouderamanagerserver.sh embedded $CMVER
echo #####################
echo You did fantastic job . Please point your favourite browser to http://Public Ip:7180 after 5 minutes and login with admin/admin.
