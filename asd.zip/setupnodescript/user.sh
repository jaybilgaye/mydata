#!/bin/bash
useradd cloud1
echo -e "cloud1rocks\ncloud1rocks" | passwd cloud1
useradd cloud3
echo -e "cloud2rocks\ncloud2rocks" | passwd cloud2

useradd cloud3
echo -e "cloud3rocks\ncloud3rocks" | passwd cloud3
  useradd cloud4
echo -e "cloud4rocks\ncloud4rocks" | passwd cloud4

useradd cloud5
echo -e "cloud5rocks\ncloud5rocks" | passwd cloud5

useradd cloud6
echo -e "cloud6rocks\ncloud6rocks" | passwd cloud6

useradd cloud7
echo -e "cloud7rocks\ncloud7rocks" | passwd cloud7

useradd cloud8
echo -e "cloud8rocks\ncloud8rocks" | passwd cloud8

useradd cloud9
echo -e "cloud9rocks\ncloud9rocks" | passwd cloud9

useradd cloud10
echo -e "cloud10rocks\ncloud10rocks" | passwd cloud10  

echo "10 user added"
 useradd cloud11
echo -e "cloud11rocks\ncloud11rocks" | passwd cloud11

useradd cloud12
echo -e "cloud12rocks\ncloud12rocks" | passwd cloud12

useradd cloud13
echo -e "cloud13rocks\ncloud13rocks" | passwd cloud13

useradd cloud14
echo -e "cloud14rocks\ncloud14rocks" | passwd cloud14

useradd cloud15
echo -e "cloud15rocks\ncloud15rocks" | passwd cloud15

