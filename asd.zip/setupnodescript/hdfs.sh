#!/bin/sh
    for i in `more userlist.txt `
    do
    echo $i
    #useradd -g development $i
    echo "user Has been Added"
    sudo -u hdfs hadoop fs -mkdir -p /user/$i
    sudo -u hdfs hadoop fs -chown -R $i:$i /user/$i
    hdfs dfs -ls /user/$i
    done
