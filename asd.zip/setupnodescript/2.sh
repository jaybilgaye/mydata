#!/bin/bash

echo Hello, This is specific to Cloudera Agent installation.

hostname -f 
hostname


echo Please enter your CM server Private Hostname
read cmservername

echo ######################################################################
#echo Hello $varname , Welcome to pre-requisites set up for CM installation 
echo ######################################################################


echo Install Cloudera Manager agent on All remaining nodes.
#CMSERVER=ip-172-31-45-140.us-west-2.compute.internal
CMSERVER=$cmservername

echo Please enter CMVER value like CMVER=5.10.2 or 5.12 to install agent  on nodes.This take some minutes.Be PaTIENT.
read cmver

#CMVER=5.10.2
CMVER=$cmver

cd /root/hadoop-deployment-bash/

echo Installing cloudera manager agent for given CMSERVER 

./install_clouderamanageragent.sh $CMSERVER $CMVER
