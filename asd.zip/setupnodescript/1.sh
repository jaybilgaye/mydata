#!/bin/bash

echo Hello, who am I talking to?
read varname

echo ######################################################################
echo Hello $varname , Welcome to pre-requisites set up for any Hadoop installation 
echo ######################################################################


yum install -y git wget python unzip
sleep 5
git clone https://github.com/teamclairvoyant/hadoop-deployment-bash
sleep 2
cd /root/hadoop-deployment-bash/
sleep 2
echo ######################################################################
echo Which JDK do you want to install in this machine just write 7 or 8 ?
echo ######################################################################
echo Please enter value 7 for OpenJDK7 and 8 for OpenJDK8
read jdkversion

JDKVER=$jdkversion
./install_jdk.sh $JDKVER

echo ######################################################################
echo Installing NTP and other tools for you , relax.
echo ######################################################################
./install_ntp.sh

./disable_selinux.sh
./disable_thp.sh
./disable_iptables.sh
./install_tools.sh
echo ######################################################################
echo Prerequisites are done .Great work $varname, You deserved a drink today.
echo ######################################################################

